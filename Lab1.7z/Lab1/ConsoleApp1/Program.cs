﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double a, b, c;
            double x1, x2;
            while (true)
            {
                Console.WriteLine("Введите число a");

                if (double.TryParse(Console.ReadLine(), out a))
                {
                    if (a == 0)
                    {
                        Console.WriteLine("Вы ввели число 0. Это не квадратное уравнение. Продолжить?");
                        string s = Console.ReadLine();
                        if (s == "Yes" || s == "yes" || s == "Да" || s == "да")
                        {
                            break;
                        }
                        else
                        {
                            Console.ReadKey();
                            Console.Clear();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели число " + a.ToString());
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не число");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
           
           while(true)
            {
                Console.WriteLine("Введите число b");
                if (double.TryParse(Console.ReadLine(), out b))
                {
                    if (a == 0 && b == 0)
                    {
                        Console.WriteLine("Вы ввели число " + b.ToString());
                        Console.WriteLine("Это не уравнение");
                        //код выхода
                        System.Environment.Exit(0);
                    }
                    else
                    {

                        Console.WriteLine("Вы ввели число " + b.ToString());                     
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не число");
                    Console.ReadKey();
                    Console.Clear();
                    Console.WriteLine("a = " + a.ToString());
                }
            }

            while (true)
            {
                Console.WriteLine("Введите число c");
                if (double.TryParse(Console.ReadLine(), out c))
                {
                    if (a == 0 && b > 0)
                    {
                        Console.WriteLine("Вы ввели число " + c.ToString());
                        x1 = (-c) / b;
                       
                        Console.WriteLine("Корень уравнения один: {0}", x1);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели число " + c.ToString());
                        if(b == 0 && a != 0)
                        {
                            if((a>0 && c >0) || (a<0 && c<0))
                            {
                                Console.WriteLine("Корней нет");
                                break;
                            }
                            else
                            {
                                x1 = Math.Sqrt((-c) / a);
                                x2 = -(Math.Sqrt((-c) / a));
                                Console.WriteLine("Корни уравнения: {0} и {1}", x1, x2);
                            }
                        }
                        break;
                    }

                    
                }
                else
                {
                    Console.WriteLine("Вы ввели не число");
                    Console.ReadKey();
                    Console.Clear();
                    Console.WriteLine("a = " + a.ToString());
                    Console.WriteLine("b = " + b.ToString());
                }
            }

            ///<summary>
            ///Дискриминант
            ///</summary>
            if (a != 0 && b != 0)
            {
                double d = b * b - 4 * a * c;
                if(d > 0)
                {
                    Console.WriteLine("Дискриминант: {0}", d);
                    x1 = (-b + Math.Sqrt(d)) / (2 * a);
                    x2 = (-b - Math.Sqrt(d)) / (2 * a);
                    Console.WriteLine("Корни уравнения: {0:F2} и {1:F2}", x1, x2);
                }
                else if(d == 0)
                {
                    Console.WriteLine("Дискриминант: {0}", d);
                    x1 = -b / (2 * a);              
                    Console.WriteLine("Корень уравнения: {0}", x1);
                }
                else
                {
                    Console.WriteLine("D < 0. Нет корней");
                }
            }

        }
    }
}
